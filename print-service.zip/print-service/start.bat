@echo off
chcp 65001 >nul
echo ==========================================
echo  PRINT SERVICE - Restaurante Suances
echo ==========================================
echo.

REM Verificar Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python no está instalado o no está en el PATH
    echo Por favor instala Python 3.8+ desde https://python.org
    pause
    exit /b 1
)

echo [OK] Python detectado

REM Verificar si existe configuración
if not exist "config.properties" (
    echo.
    echo ==========================================
    echo  PRIMERA CONFIGURACIÓN
    echo ==========================================
    echo.
    echo No se encontró archivo de configuración.
    echo Vamos a configurar el sistema paso a paso.
    echo.
    python setup.py
    if errorlevel 1 (
        echo.
        echo [ERROR] La configuración no se completó
        pause
        exit /b 1
    )
    echo.
    echo ==========================================
    echo  CONFIGURACIÓN COMPLETADA
    echo ==========================================
    echo.
)

REM Preguntar si quiere reconfigurar
echo.
echo Opciones:
echo  1. Iniciar servicio de impresión
echo  2. Reconfigurar (cambiar ubicación/impresora)
echo.
set /p choice="Elige una opción (1-2): "

if "%choice%"=="2" (
    echo.
    python setup.py
    if errorlevel 1 (
        echo.
        echo [ERROR] La configuración no se completó
        pause
        exit /b 1
    )
)

REM Verificar dependencias
echo.
echo Verificando dependencias...
python -c "import redis" >nul 2>&1
if errorlevel 1 (
    echo [INFO] Instalando dependencias...
    pip install -r requirements.txt
)

echo [OK] Dependencias listas

REM Verificar configuracion
if not exist "config.properties" (
    echo [ERROR] No se encontró config.properties
    pause
    exit /b 1
)

echo.
echo ==========================================
echo  CONFIGURACIÓN ACTUAL
echo ==========================================
echo.
echo Impresora configurada: 
findstr "printer-name" config.properties | findstr /v "#"
echo.
echo Canales suscritos:
findstr "channels" config.properties | findstr /v "#"
echo.
echo Redis:
findstr "redis-host" config.properties | findstr /v "#"
findstr "redis-port" config.properties | findstr /v "#"
echo.

REM Preguntar confirmación
echo ¿Deseas iniciar el servicio con esta configuración?
set /p confirm="(S/n): "
if /i "%confirm%"=="n" (
    echo.
    echo Servicio no iniciado.
    pause
    exit /b 0
)

echo.
echo ==========================================
echo  INICIANDO PRINT SERVICE...
echo ==========================================
echo.
echo Presiona Ctrl+C para detener
echo.

python src\print_client.py

if errorlevel 1 (
    echo.
    echo [ERROR] El servicio se detuvo con errores
    echo.
    echo Posibles causas:
    echo  - Redis no está disponible
    echo  - La impresora no está conectada
    echo  - Error en la configuración
    echo.
    pause
)
