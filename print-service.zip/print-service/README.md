# Sistema de Impresión - Restaurante Suances

## Descripción General

Sistema de impresión distribuido que permite imprimir tickets de cocina, barra y cuentas en diferentes impresoras ubicadas en distintos puntos del restaurante.

## Arquitectura

```
┌─────────────────┐     ┌──────────────────┐     ┌─────────────────────┐
│  Frontend App   │────▶│  Backend Java    │────▶│   Redis Pub/Sub     │
│  (React Native) │     │  (Spring Boot)   │     │                     │
└─────────────────┘     └──────────────────┘     └──────────┬──────────┘
                                                            │
                              ┌─────────────────────────────┼─────────────┐
                              │                             │             │
                     ┌────────▼────────┐         ┌─────────▼─────┐ ┌─────▼──────┐
                     │ PC Cocina       │         │ PC Isabella   │ │ PC Faro    │
                     │ print-service   │         │ print-service │ │print-service│
                     │ Canal:          │         │ Canales:      │ │Canal:      │
                     │ print/cocina    │         │print/ticket-  │ │print/ticket│
                     │ Printer:        │         │ isabella      │ │ -faro      │
                     │ POSIFLEX PP-6900│         │ print/barra   │ │Printer:    │
                     └─────────────────┘         │ Printer:      │ │POSIFLEX    │
                                                  │POSIFLEX PP-6900│ PP-6900   │
                                                  └───────────────┘ └───────────┘
```

## Componentes

### 1. Backend (Java Spring Boot)

#### Archivos modificados:

**SalaEventProducer.java**
- Nuevos canales Redis: `print/cocina`, `print/barra`
- Nuevos métodos:
  - `publicarTicketCuentaImpresion()` - Tickets de cuenta (Isabella/Faro)
  - `publicarTicketCocinaImpresion()` - Tickets de cocina
  - `publicarTicketBarraImpresion()` - Tickets de barra

**ItemComandaService.java**
- Modifica `enviarItemsACocina()` para separar items:
  - **Cocina**: ENTRANTE, PRIMERO, SEGUNDO, POSTRE
  - **Barra**: BEBIDA, SIN_ORDEN
- Imprime automáticamente tickets separados

**CuentaController.java**
- `POST /comandas/{id}/cuenta/cerrar` - Acepta parámetro `impresora`
- `POST /comandas/{id}/cuenta/ticket/reenviar` - Implementado con selección de impresora

**CuentaService.java**
- `cerrarCuenta(comandaId, impresoraDestino)` - Cierra cuenta e imprime
- `reenviarTicket(comandaId, impresoraDestino)` - Reimprime ticket existente

**application.yml**
```yaml
app:
  redis:
    print-channel: print/ticket
    print-cocina-channel: print/cocina
    print-barra-channel: print/barra
  printer:
    isabella-name: Isabella
    faro-name: Faro
    cocina-name: Cocina
    barra-name: Isabella
```

### 2. Frontend (React Native)

#### Archivos modificados:

**ModalSelectorImpresora.tsx** (Nuevo)
- Modal visual para seleccionar impresora
- Opciones: Barra Isabella, Barra Faro
- Diseño con iconos y colores diferenciados

**TicketScreen.tsx**
- Integra el modal de selección de impresora
- Se usa tanto para imprimir como para reimprimir

**salaService.ts**
- `cerrarComanda(id, impresora?)` - Ahora acepta impresora
- `reenviarTicket(id, impresora)` - Ahora requiere impresora

**salaStore.ts**
- Actualizadas interfaces y implementaciones

### 3. Print Service (Python)

**print_client.py**
- Soporta múltiples canales simultáneos
- Tipos de tickets:
  - `TICKET_COCINA` - Sin precios, info completa
  - `TICKET_BARRA` - Sin precios, info completa
  - `TICKET_CUENTA` - Con precios, totales
- Optimizaciones:
  - Procesamiento en cola con thread dedicado
  - Idempotencia (previene duplicados)
  - Reintentos automáticos (max 3)
  - Manejo de señales (SIGINT, SIGTERM)

**config.properties**
```ini
[redis]
redis-host=localhost
redis-port=6379
channels=print/ticket,print/cocina,print/barra

[printer]
printer-name=POSIFLEX PP-6900
printer-type=windows  # windows, usb, serial
```

## Flujos de Impresión

### Flujo 1: Enviar Ronda a Cocina

Cuando se envían items a cocina (botón "Enviar a cocina"):

1. **Frontend** llama a `enviarACocina()` o `crearYEnviarACocina()`
2. **Backend** separa items:
   - **Cocina**: Items marcados como ENTRANTE, PRIMERO, SEGUNDO, POSTRE
   - **Barra**: Items sin marca (BEBIDA, SIN_ORDEN)
3. **Backend** publica tickets:
   - Ticket de cocina → Canal `print/cocina`
   - Ticket de barra → Canal `print/barra`
4. **Print Clients** reciben e imprimen:
   - PC Cocina imprime ticket de cocina
   - PC Isabella imprime ticket de barra

### Flujo 2: Imprimir Cuenta

Cuando se cierra una cuenta:

1. **Frontend** muestra modal para seleccionar impresora (Isabella/Faro)
2. **Frontend** llama a `cerrarComanda(id, impresora)`
3. **Backend** publica ticket completo con:
   - Todos los items agrupados por rondas
   - Subtotal, descuento, total
   - Info de mesa, camarero, comensales
4. **Print Client** correspondiente recibe e imprime ticket de cuenta

### Flujo 3: Reimprimir Ticket

Cuando se quiere reimprimir un ticket:

1. **Frontend** muestra modal para seleccionar impresora
2. **Frontend** llama a `reenviarTicket(id, impresora)`
3. **Backend** valida que la comanda esté cerrada/cobrada
4. **Backend** publica ticket completo al canal
5. **Print Client** correspondiente recibe e imprime

## Configuración de PCs

### ⚡ Configuración Automática (Recomendado)

Simplemente ejecuta `start.bat` y sigue las instrucciones interactivas:

```cmd
cd C:\Users\Jlemonn1\Desktop\Suances\print-service
start.bat
```

El configurador te preguntará:
1. **Ubicación**: ¿Dónde está este ordenador? (Cocina/Isabella/Faro)
2. **Redis**: Host y puerto del servidor Redis
3. **Impresora**: Nombre exacto de la impresora en Windows
4. **Tipo**: Conexión (Windows Spooler/USB/Serial)

### Configuración Manual

Si prefieres configurar manualmente, edita `config.properties`:

#### PC Cocina
```ini
[redis]
redis-host=localhost
redis-port=6379
channels=print/cocina

[printer]
printer-name=POSIFLEX PP-6900
printer-type=windows
```

#### PC Isabella (Barra)
```ini
[redis]
redis-host=localhost
redis-port=6379
channels=print/ticket-isabella,print/barra

[printer]
printer-name=POSIFLEX PP-6900
printer-type=windows
```

#### PC Faro (Barra)
```ini
[redis]
redis-host=localhost
redis-port=6379
channels=print/ticket-faro

[printer]
printer-name=POSIFLEX PP-6900
printer-type=windows
```

## Formato de Tickets

### Ticket de Cocina
```
*** COCINA ***
==================
Mesa: 5
Cod: C-001
Camarero: Juan
------------------
2x Gambas al ajillo
   [ENTRANTE]
1x Solomillo
   [PRIMERO]
   **Poco hecho**
==================
14:32:15

[Cut]
```

### Ticket de Barra
```
*** BARRA ***
==================
Mesa: 5
Cod: C-001
Camarero: Juan
------------------
2x Coca-Cola
   **Sin hielo**
1x Cerveza Estrella
==================
14:32:15

[Cut]
```

### Ticket de Cuenta
```
RESTAURANTE SUANCES
==================
Mesa: 5 - Cod: C-001
Camarero: Juan
Comensales: 4
------------------

[ENTRANTE]
2x Gambas al ajillo              12.00
1x Ensalada mixta                 8.50

[PRIMERO]
1x Solomillo                     18.00

[BEBIDA]
2x Coca-Cola                      5.00
------------------
Subtotal:                        43.50
Descuento:                        -2.00
==================
TOTAL:                           41.50
==================
Gracias por su visita
14/03/2026 14:35

[Cut]
```

## Instalación

### Requisitos
- Python 3.8+
- Redis Server
- Windows con impresora térmica configurada

### Dependencias

```bash
pip install redis pywin32

# Opcional: para impresoras USB ESC/POS
pip install python-escpos

# Opcional: para conexión serial
pip install pyserial
```

### Pasos

1. **Instalar dependencias Python**:
```bash
cd print-service
pip install -r requirements.txt
```

2. **Configurar impresora en Windows**:
   - Instalar drivers de la impresora
   - Verificar el nombre exacto en: Panel de Control > Dispositivos e Impresoras
   - Anota el nombre exacto (ej: "POSIFLEX PP-6900")

3. **Ejecutar configurador** (la primera vez):
```bash
start.bat
```
   - Selecciona la ubicación de esta PC
   - Introduce el nombre exacto de la impresora
   - El configurador creará automáticamente `config.properties`

4. **Iniciar servicio**:
```bash
start.bat
```
   - O simplemente haz doble clic en `start.bat`

**Para reconfigurar** (cambiar de ubicación o impresora):
```bash
python setup.py
```

## Monitorización

Logs del sistema:
```bash
# En cada PC
tail -f print-service/logs/print_client.log

# Redis - Ver canales
redis-cli
> PUBLISH print/ticket '{"test": true}'
> SUBSCRIBE print/ticket print/cocina print/barra
```

## Troubleshooting

### Problema: No se reciben mensajes
- Verificar conexión Redis: `redis-cli ping`
- Verificar canales suscritos en config.properties
- Revisar logs del print_client
- Verificar que Redis pub/sub está activo

### Problema: No se imprime
- Verificar nombre de impresora en config.properties coincide exactamente con Windows
- Probar impresora desde Windows: Panel de Control > Dispositivos e Impresoras > Imprimir página de prueba
- Verificar que el servicio de cola de impresión está activo: `services.msc` → Cola de impresión
- Ejecutar print_client.py como administrador

### Problema: Tickets duplicados
- Verificar TTL de idempotencia en Redis: `KEYS printed:*`
- Revisar que los tickets tienen ID único
- Los tickets duplicados son ignorados automáticamente por 24h

### Problema: Caracteres extraños
- Verificar codificación UTF-8 en impresora
- Para ESC/POS: Usar `p.charcode("UTF8")`
- Probar con diferentes fuentes en la impresora

### Problema: Conexión Redis intermitente
- Verificar red entre PC y servidor Redis
- Revisar firewall (puerto 6379)
- Configurar `health_check_interval` en el cliente

## Variables de Entorno

El backend puede configurarse con estas variables de entorno:

```bash
# Redis
SPRING_DATA_REDIS_HOST=localhost
SPRING_DATA_REDIS_PORT=6379

# Canales de impresión
APP_REDIS_PRINT_CHANNEL=print/ticket
APP_REDIS_PRINT_COCINA_CHANNEL=print/cocina
APP_REDIS_PRINT_BARRA_CHANNEL=print/barra
APP_REDIS_PRINT_ISABELLA_CHANNEL=print/ticket-isabella
APP_REDIS_PRINT_FARO_CHANNEL=print/ticket-faro

# Nombre físico de la impresora (todas las ubicaciones usan el mismo modelo)
APP_PRINTER_NAME=POSIFLEX PP-6900
```

## Seguridad

- **Idempotencia**: Previene impresión duplicada (TTL 24h en Redis)
- **Validación**: Solo impresoras configuradas (Isabella/Faro)
- **Estados**: Solo se reimprimen comandas cerradas/cobradas
- **Autenticación**: Endpoints protegidos con JWT (roles: OWNER, MANAGER, WAITER)

## Mejoras Futuras

- [ ] Soporte para impresoras USB directo (ESC/POS)
- [ ] Soporte para impresoras en red (Ethernet/WiFi)
- [ ] Dashboard web para monitorización en tiempo real
- [ ] Estadísticas de impresión (volumen, horas pico)
- [ ] Cola de impresión persistente ante caídas
- [ ] Notificaciones de errores de impresión
- [ ] Soporte para múltiples idiomas en tickets
- [ ] Códigos QR en tickets de cuenta

## Changelog

### v2.1 (2024-03-14)
- **Canales independientes**: Separados `print/ticket-isabella` y `print/ticket-faro`
- **Configurador automático**: Script interactivo `setup.py` para configurar la PC
- **Canales optimizados**: Cada PC solo escucha los canales que necesita
- **Mejor UX**: `start.bat` con menú interactivo y opción de reconfigurar

### v2.0 (2024-03)
- Sistema multi-impresora (Cocina, Isabella, Faro)
- Tickets separados para cocina y barra
- Modal de selección de impresora
- Soporte para reimpresión con selección de destino
- Optimización del cliente Python (colas, threads, reintentos)

### v1.0 (2024-02)
- Impresión básica de tickets de cuenta
- Canal único Redis
- Cliente Python simple
